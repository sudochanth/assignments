import React from 'react';

const Pokedex = () => {
    return (
        <div>
            pokedex
        </div>
    );
};

export default Pokedex;