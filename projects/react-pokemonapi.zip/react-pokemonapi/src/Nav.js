import React from 'react';

const Nav = () => {
    return (
        <div>
            <ul></ul>
            <ul></ul>
            <ul></ul>
        </div>
    );
};

export default Nav;